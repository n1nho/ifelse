#include <stdio.h>

int main(void) {
  int valor1=0;
  printf ("digte o seu valor\n");
  scanf ("%i",&valor1);
  if (valor1>=0){
    printf ("positvo");
  }
  else {
    printf ("negativo");
  }
    return 0;
}