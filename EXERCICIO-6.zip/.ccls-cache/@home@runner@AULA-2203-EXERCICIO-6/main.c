#include <stdio.h>

int main(void) {
  int valor1, valor2;
    printf ("digite seus valores\n");
  scanf ("%i", &valor1);
  scanf ("%i", &valor2);
  if ("%i",valor1 > valor2)
    printf ("o primeiro número é maior que o segundo");
   else 
    printf ("o segundo número é maior que o primeiro");
  
  return 0;
    }
 
   
  