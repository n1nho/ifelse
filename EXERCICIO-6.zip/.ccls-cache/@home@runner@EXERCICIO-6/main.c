#include <stdio.h>

int main(void) {
  int valor1, valor2;
    printf ("digite seus valores\n");
  scanf ("%i", &valor1);
  scanf ("%i", &valor2);
  if ("%i",valor1 > valor2)
    printf ("o %i é maior que o %i", valor1, valor2);
   else 
    printf ("o %i é maior que o %i", valor2, valor1);
  
  return 0;
    }
 
   
  