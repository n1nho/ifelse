#include <stdio.h>

int main(void) {
  int valor1, valor2;
    printf ("digite seus valores\n");
  if (valor1 > valor2)
   printf (int valor1, "é maior que o",valor2);
else
   printf (int valor2, "é maior que o",valor1);
  
  return 0;
   
    }
