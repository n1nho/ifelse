#include <stdio.h>

int main(void) {
  int data;
  printf ("digite seu ano de nascimento \n");
  scanf ("%i", &data);
  if (data>2004)
    printf ("você não pode votar");
  else {
    printf ("você pode votar");
  }
  return 0;
}