#include <stdio.h>

int main(void) {
  int valor1;
  printf ("digite seu valor \n");
  scanf ("%i", &valor1);
  if (valor1 >= 1 && valor1 <=9)
    printf ("o valor está dentro da faixa permitida");
  
  else {
    printf ("o valor está fora da faixa permitida");
  } return 0;
}