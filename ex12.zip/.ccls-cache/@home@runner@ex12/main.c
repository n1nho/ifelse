#include <stdio.h>

int main(void) {
  int senhax;
  printf ("digite sua senha de 4 digitos:\n");
  scanf ("%i", &senhax);
  if  (senhax==1234) { 
  printf ("acesso permitido"); 
    }
  else { 
    printf ("acesso negado");
    }
  

 


  return 0;
}