#include <stdio.h>

int main(void) {
  float valor1, valor2, media;
 printf ("digite suas notas \n");
  scanf ("%f",&valor1);
  scanf ("%f",&valor2);
  media = (valor1 + valor2) /2;
  printf ("media %.1f\n",media);
  if (media >=6){
    printf ("você foi aprovado");
  }
else if (media >3 && media <6){
  printf ("exame");
  }
  else{
    printf ("reprovado"); }
    
  
{
 
}
  return 0;
}